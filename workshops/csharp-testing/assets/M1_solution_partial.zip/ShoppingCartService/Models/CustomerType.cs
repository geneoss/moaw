﻿namespace ShoppingCartService.Models
{
    /// <summary>
    /// Customer type
    /// </summary>
    public enum CustomerType
    {
        Standard,
        Premium
    }
}