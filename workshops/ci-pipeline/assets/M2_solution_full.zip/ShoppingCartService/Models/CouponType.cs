﻿namespace ShoppingCartService.Models
{
    public enum CouponType
    {
        Amount,
        Percentage,
        FreeShipping
    }
}