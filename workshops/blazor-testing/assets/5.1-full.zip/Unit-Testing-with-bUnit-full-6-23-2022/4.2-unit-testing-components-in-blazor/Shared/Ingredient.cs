﻿using System.Collections.Generic;

namespace BellyBox.Shared
{
    public class Ingredient
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }

}