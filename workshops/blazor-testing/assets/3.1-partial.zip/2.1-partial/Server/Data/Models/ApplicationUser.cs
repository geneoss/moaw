﻿using Microsoft.AspNetCore.Identity;

namespace BellyBox.Server.Models
{
    public class ApplicationUser : IdentityUser
    {
    }
}