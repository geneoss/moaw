﻿using System.Collections.Generic;

namespace BellyBox.Shared
{
    public class Tag
    {
        public int Id { get; set; }
        public string Text { get; set; }
    }
}