# simple-app-with-webassembly-lp-author
Repository for liveProject: Simple App with WebAssembly
