﻿using System.Collections.Generic;
using System.Linq;
using BellyBox.Shared;

namespace BellyBox.Tests;

public static class MealViewData
{
    /// <summary>
    /// Creates an array of test meals using a template where n is the item number:
    /// </summary>
    /// <returns>
    public static Meal[] GetFakeMeals(int records) =>
        /* Complete Statement */

    public static Tag[] GetFakeTags(int start, int count) =>
        /* Complete Statement */

    private static IEnumerable<Ingredient> GetFakeIngredients(int n) =>
        /* Complete Statement */
}

